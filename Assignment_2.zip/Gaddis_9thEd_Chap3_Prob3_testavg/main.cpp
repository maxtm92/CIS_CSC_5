/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on sept 16, 2018, 8:00 pM
 * Purpose:  
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants  Physics/Math/Conversions/Array Dimension

//Function Prototypes

//Execution begins with main
int main(int argc, char** argv) {
 
    //Declare Variables
    float classA,//class a 
            classB,//class b
            classC,//class c 
            classD,//class D
            classF,//class f
            avg;
            
    
    
    //Initialize Variables
     cout<<"This program determines the average test score of five tests"<<endl;
    cout<<"Input score of test 1: "<<endl;
    cin>>classA;
     cout<<"Input score of test 2: "<<endl;
    cin>>classB;
 cout<<"Input score of test 3: "<<endl;
    cin>>classC;
    cout<<"Input score of test 4: "<<endl;
    cin>>classD;
    cout<<"Input score of test 5: "<<endl;
    cin>>classF;


        //Map or process the Variables to their outputs
    avg=(classA+classB+classC+classD+classF)/5;
    //Display or return the output
     cout<<"The average is "<<fixed <<setprecision(2) <<avg<<" points/percent"<<endl;
    

    return 0;
}