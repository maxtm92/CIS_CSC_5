/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on Sept, 2018, 7:26 M
 * Purpose:  Calculate gas mileage
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants  Physics/Math/Conversions/Array Dimension

//Function Prototypes

//Execution begins with main
int main(int argc, char** argv) {
    //Declare Variables
    float mpg,//miles per gallon
            tnksze,//tank size
            mpt;//miles per tank
    //Initialize Variables
    cout<<"This program determines total miles per gallon on your car."<<endl;
    cout<<"Input miles per tank : "<<endl;
    cin>>mpt;
    cout<<"Input tank size of your car : "<<endl;
    cin>>tnksze;
    //Map or process the Variables to their outputs
    mpg=tnksze/mpt;
    //Display or return the output
         cout<<"The total miles per hour is "<<mpg<<" per gallon"<<endl;

    return 0;
}