/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on September 16, 2018, 8:39 PM
 */
//Libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;
//User Libraries

//Global Constants  Physics/Math/Conversions/Array Dimension
const char percent=100;
//Function Prototypes

//Execution begins with main

int main(int argc, char** argv) {
//Declare Variables
    float repcost,
            minins=0.8,
            amtins;
//Initialize Variables
        cout<<"This program determines the minimum amount of insurance you should get on your building"<<endl;
    cout<<"Input total replacement cost for your building"<<endl;
    cin>>repcost;
    
//Map or process the Variables to their outputs
    amtins=(repcost*minins);
//Display or return the output
    
  cout<<"The amount you should insure is  "<<amtins
            <<" dollars"<<endl;
    return 0;
}

