/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on sept 16, 2018, 8:13 pM
 * Purpose:  
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants  Physics/Math/Conversions/Array Dimension

//Function Prototypes

//Execution begins with main
int main(int argc, char** argv) {
 
    //Declare Variables
    float monthA,
            monthB,
            monthC,
            rainA,
            rainB,
            rainC,
            avg;
            
    
    
    //Initialize Variables
     cout<<"This program determines the average rainfall of three months"<<endl;
    cout<<"Input month name of the first month: "<<endl;
    cin>>monthA;
     cout<<"Input month name of the second month: "<<endl;
    cin>>monthB;
    cout<<"Input month name of the third month: "<<endl;
    cin>>monthC;
    cout<<"Input average rainfall of the first month: "<<endl;
    cin>>rainA;
    cout<<"Input average rainfall of the second month: "<<endl;
    cin>>rainB;
     cout<<"Input average rainfall of the second month: "<<endl;
    cin>>rainC;


        //Map or process the Variables to their outputs
    avg=(rainA+rainB+rainC)/3;
    //Display or return the output
     cout<<"The average is "<<fixed <<setprecision(1) <<avg<<" inches"<<endl;
    

    return 0;
}

