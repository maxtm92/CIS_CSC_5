/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on September 13, 2018,11:27 AM
 * Purpose:  Math Tutor Problem
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //set random number seed
        srand(static_cast<unsigned int>(time(0)));
    //Declare all Variables Here
        unsigned short op1,//operand 1
                       op2,//operand 2
                       result,//op1+op2
                       stuAns;//student answer
    //Input or initialize values Here
        op1=100+rand()%900;//3 digit number
        op2= 10+rand()%990;//2 or 3 digit
    //Process/Calculations Here
        result=op1+op2;
    
    //Output Located Here
        
    cout<<setw(6)<<op1<<endl;
    cout<<" + "<<setw(3)<<op2<<endl;
    cout<<"------"<<endl;
    cout<<(result>=1000?"  ":"   ");//if the result is bigger than 999 use 2 spaces
    cin>>stuAns;
    cout<<setw(6)<<result<<endl;
  cout<<setw(4)<<stuAns<<(result==stuAns?" is Correct":" is Incorrect")
          <<" the correct answer is "<<result<<endl;
    
    //Exit
    return 0;
}

