
/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on sept 16, 2018, 8:28 pM
 * Purpose:  
*/
//Libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

//User Libraries

//Global Constants  Physics/Math/Conversions/Array Dimension
const char PERCENT=100;
//Function Prototypes

//Execution begins with main

int main(int argc, char** argv) {
     //Declare Variables
    float numMle,//number of male
            numFmle,//number of female
            perMle,//percentage of male
            perFmle,//percentage of female
            totStu;//total students
     //Initialize Variables
    cout<<"This program determines the percentage of male and female students in a class"<<endl;
    cout<<"Input number of female students"<<endl;
    cin>>numFmle;
    cout<<"Input number of male students"<<endl;
    cin>>numMle;
    
     //Map or process the Variables to their outputs
    totStu=numMle+numFmle;
    perMle=(numMle/totStu)*PERCENT;
    perFmle=(numFmle/totStu)*PERCENT;
     //Display or return the output
    cout<<"The percent of female students in the class is "<<perFmle<<" Percent"<<endl;
        cout<<"The percent of male students in the class is "<<perMle<<" Percent"<<endl;

    return 0;
}

