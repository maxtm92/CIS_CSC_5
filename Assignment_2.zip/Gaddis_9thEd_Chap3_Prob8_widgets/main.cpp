/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on September 16, 2018, 8:39 PM
 */
//Libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;
//User Libraries

//Global Constants  Physics/Math/Conversions/Array Dimension

//Function Prototypes

//Execution begins with main

int main(int argc, char** argv) {
//Declare Variables
    float totlbs,
            numwid,
            pallet,
            widwgt;
    float widgt=12.5;
            
//Initialize Variables
   cout<<"This program determines the total weight of a pallet of widgets"<<endl;
    cout<<"Input pallet weight"<<endl;
    cin>>pallet;
    cout<<"Input total weight"<<endl;
    cin>>totlbs;
    widwgt=totlbs-pallet;
    numwid=widwgt/widgt;
//Map or process the Variables to their outputs
     cout<<"The number of widgets on the pallet is "<<numwid<<" widgets"<<endl;
    
//Display or return the output
    
    return 0;
}

