/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on September 13, 2018,11:27 AM
 * Purpose:  BMR Calculator
 */
//System Libraries Here
#include <iostream>//I/o Library ->cout,endl
#include <iomanip>//format library
#include <cstdlib>// random and set seed
#include <ctime>//time to set the seed
using namespace std;//namespace I/o stream library

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    srand(static_cast<unsigned int>(time(0)));
    //Declare all Variables Here
    unsigned char  sex,//male or female
                   wt,//weight in lbs
                   ht,//height in inches
                   age;//age in years
    unsigned short bmr,//basal metabolic rate
                   calBar;//calories in each bar    
    float          nBars;//number of candy bars
    //Input or initialize values Here
    calBar=230;//from book
    sex=rand()%2>0?'M':'F';
    wt=100+rand()%111;//100-210
    ht=60+rand()%17;//60-76
    age=18+rand()%51;//18-68
    
    //Process/Calculations Here
    bmr = sex=='F'?
            655 + 4.3*wt + 4.7*ht + 4.7*age:
        66 + 6.3*wt + 12.9*ht + 6.8*age;
    nBars=static_cast<float>(bmr)/calBar;
    //Output Located Here'
    cout<<"Stats for Candy Bars"<<endl;
    cout<<"Sex    = "<<sex<<endl;
    cout<<"Weight = "<<static_cast<int>(wt)<<" lbs"<<endl;
    cout<<"Height = "<<static_cast<int>(ht)<<" inc"<<endl;
    cout<<"Age    = "<<static_cast<int>(age)<<" yrs"<<endl;
    cout<<"BMR    ="<< bmr<<" cals"<<endl;
    cout<<"# C-Bars to consume ="<<nBars<<endl;
    //Exit
    return 0;
}

