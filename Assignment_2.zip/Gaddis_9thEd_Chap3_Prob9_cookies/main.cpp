/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on September 16, 2018, 8:39 PM
 */
//Libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;
//User Libraries

//Global Constants  Physics/Math/Conversions/Array Dimension

//Function Prototypes

//Execution begins with main

int main(int argc, char** argv) {
//Declare Variables
    char ckycal=100;
    float numcky,
            totcal;
//Initialize Variables
       cout<<"This program determines the total number of calories consumed"<<endl;
    cout<<"Input total number of cookies consumed"<<endl;
    cin>>numcky;
    
//Map or process the Variables to their outputs
    totcal=numcky*ckycal;
//Display or return the output
         cout<<"The number of calories consumed is  "<<totcal
            <<" calories"<<endl;
    return 0;
}

