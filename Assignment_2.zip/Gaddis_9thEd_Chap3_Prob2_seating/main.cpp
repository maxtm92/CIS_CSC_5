/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on sept 16, 2018, 7:36 pM
 * Purpose:  
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants  Physics/Math/Conversions/Array Dimension

//Function Prototypes

//Execution begins with main
int main(int argc, char** argv) {
 
    //Declare Variables
    char classA=15.00,//class a seat price
            classB=12.00,//class b seat price
            classC=9.00;//class c seat price
    float totRev,//total ticket revenue
            saleA,//# seat a sales
            saleB,//# seat b sales
            saleC;//# seat c sales
            
    
    
    //Initialize Variables
     cout<<"This program determines total revenue made on ticket sales"<<endl;
    cout<<"Input # of class A tickets sold : "<<endl;
    cin>>saleA;
     cout<<"Input # of class B tickets sold : "<<endl;
    cin>>saleB;
 cout<<"Input # of class C tickets sold : "<<endl;
    cin>>saleC;


        //Map or process the Variables to their outputs
         totRev=(classA*saleA)+(classB*saleB)+(classC*saleC);
    //Display or return the output
     cout<<"The total revenue = "<<fixed <<setprecision(2) <<totRev<<" dollars"<<endl;
    

    return 0;
}