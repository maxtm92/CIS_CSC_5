/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on Sept 07, 2018, 1:51 AM
 * Purpose:  Calculate a restaurant bill
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants  Physics/Math/Conversions/Array Dimension

//Function Prototypes

//Execution begins with main
int main(int argc, char** argv) {
    //Declare Variables
    float bill,
            billTx=.0675,//Tax percentage on purchases
            amtTx,//the amount of tax on the bill
            tip=.2,//the percentage of tip 
            amtTp,//the cost of tip on a bill
            ttlBll;//the total cost of the entire bill
            
  //Input or initialize values Here
    cout<<"This program determines total sales tax on a meal purchase"<<endl;
    cout<<"Input meal price : "<<endl;
    cin>>bill;
    
    //Map or process the Variables to their outputs
    amtTx=bill*billTx;
    amtTp=bill*(billTx+tip);
    ttlBll=amtTp+bill;
    //Display or return the output
     cout<<"The total meal cost = "<<bill<<" dollars"<<endl;
      cout<<"The total tax cost = "<<amtTx<<" dollars"<<endl;
     cout<<"The total tip cost = "<<amtTp<<" dollars"<<endl;
      cout<<"The total cost = "<<ttlBll<<" dollars"<<endl;

    return 0;
}