/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on September 6, 2018, 10:07 PM
 * Purpose To add numbers together
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants  Physics/Math/Conversions/Array Dimension

//Function Prototypes

//Execution begins with main
int main(int argc, char** argv) {
    //Declare Variables
    float frstNum,
            scndNum,
            sumVal;
    
    
    //Initialize Variables
    
    //Map or process the Variables to their outputs
  
    //Display or return the output
    cout<<"Enter two integers: "<<endl;
    cin >> frstNum >> scndNum;
    
    sumVal = frstNum + scndNum;
    
    cout<< "The sum of the numbers: " <<sumVal << endl;
 
    

    return 0;
}

