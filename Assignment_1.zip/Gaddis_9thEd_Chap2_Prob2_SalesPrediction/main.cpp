/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on Sept 7, 2018, 12:54 AM
 * Purpose:  Calculate each sales by branch
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants  Physics/Math/Conversions/Array Dimension

//Function Prototypes

//Execution begins with main
int main(int argc, char** argv) {
    //Declare Variables
    float totlsls= 8600000,// total amount of sales
            divpct=.58,//The amount each branch makes in percent
            divwrth;//The amount each branch makes in $'s
    //Initialize Variables

    cout<<"This program will predict how much each branch of the company will generate."<<endl;
    
 
           
    //Map or process the Variables to their outputs
            divwrth=totlsls*divpct;
    //Display or return the output
            cout<<"The branch will make "<< divwrth<<" '$"<<endl;

    return 0;
}