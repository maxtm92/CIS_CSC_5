/* 
 * File:   main.cpp
 * Author: Max Lothringen
 * Created on Sept 7, 2018, 1:39 AM
 * Purpose:  Calculate sales tax
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants  Physics/Math/Conversions/Array Dimension

//Function Prototypes

//Execution begins with main
int main(int argc, char** argv) {
    //Declare Variables
    float prchs,//purchase price   
            staTax=.04,//state sales tax 
            couTax=.02,//country sales tax
            ttlTax;//total sales tax in dollars
  //Input or initialize values Here
    cout<<"This program determines total sales tax on a purchase"<<endl;
    cout<<"on a purchase"<<endl;
    cout<<"Input purchase price"<<endl;
    cin>>prchs;
    //Process/Calculations Here
    ttlTax=prchs*(staTax+couTax);
   
    //Display or return the output
    cout<<"The total sales tax = "<<ttlTax<<" dollars"<<endl;
 

    return 0;
}